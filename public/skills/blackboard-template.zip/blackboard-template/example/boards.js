// 本示例用到的视觉素材（图标 SVG path，仅示例用，按内容自行选定即可；
// 键名带连字符必须加引号）
window.ICONS = {
  "bot": "<path d=\"M12 8V4H8\" /> <rect width=\"16\" height=\"12\" x=\"4\" y=\"8\" rx=\"2\" /> <path d=\"M2 14h2\" /> <path d=\"M20 14h2\" /> <path d=\"M15 13v2\" /> <path d=\"M9 13v2\" />",
  "brain": "<path d=\"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z\" /> <path d=\"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z\" /> <path d=\"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4\" /> <path d=\"M17.599 6.5a3 3 0 0 0 .399-1.375\" /> <path d=\"M6.003 5.125A3 3 0 0 0 6.401 6.5\" /> <path d=\"M3.477 10.896a4 4 0 0 1 .585-.396\" /> <path d=\"M19.938 10.5a4 4 0 0 1 .585.396\" /> <path d=\"M6 18a4 4 0 0 1-1.967-.516\" /> <path d=\"M19.967 17.484A4 4 0 0 1 18 18\" />",
  "code": "<path d=\"m16 18 6-6-6-6\" /> <path d=\"m8 6-6 6 6 6\" />",
  "copy": "<rect width=\"14\" height=\"14\" x=\"8\" y=\"8\" rx=\"2\" ry=\"2\" /> <path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\" />",
  "cpu": "<path d=\"M12 20v2\" /> <path d=\"M12 2v2\" /> <path d=\"M17 20v2\" /> <path d=\"M17 2v2\" /> <path d=\"M2 12h2\" /> <path d=\"M2 17h2\" /> <path d=\"M2 7h2\" /> <path d=\"M20 12h2\" /> <path d=\"M20 17h2\" /> <path d=\"M20 7h2\" /> <path d=\"M7 20v2\" /> <path d=\"M7 2v2\" /> <rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\" /> <rect x=\"8\" y=\"8\" width=\"8\" height=\"8\" rx=\"1\" />",
  "database": "<ellipse cx=\"12\" cy=\"5\" rx=\"9\" ry=\"3\" /> <path d=\"M3 5V19A9 3 0 0 0 21 19V5\" /> <path d=\"M3 12A9 3 0 0 0 21 12\" />",
  "eye": "<path d=\"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0\" /> <circle cx=\"12\" cy=\"12\" r=\"3\" />",
  "file-text": "<path d=\"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z\" /> <path d=\"M14 2v4a2 2 0 0 0 2 2h4\" /> <path d=\"M10 9H8\" /> <path d=\"M16 13H8\" /> <path d=\"M16 17H8\" />",
  "funnel": "<path d=\"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z\" />",
  "gauge": "<path d=\"m12 14 4-4\" /> <path d=\"M3.34 19a10 10 0 1 1 17.32 0\" />",
  "layers": "<path d=\"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z\" /> <path d=\"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12\" /> <path d=\"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17\" />",
  "pencil": "<path d=\"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z\" /> <path d=\"m15 5 4 4\" />",
  "sigma": "<path d=\"M18 7V5a1 1 0 0 0-1-1H6.5a.5.5 0 0 0-.4.8l4.5 6a2 2 0 0 1 0 2.4l-4.5 6a.5.5 0 0 0 .4.8H17a1 1 0 0 0 1-1v-2\" />",
  "snowflake": "<path d=\"m10 20-1.25-2.5L6 18\" /> <path d=\"M10 4 8.75 6.5 6 6\" /> <path d=\"m14 20 1.25-2.5L18 18\" /> <path d=\"m14 4 1.25 2.5L18 6\" /> <path d=\"m17 21-3-6h-4\" /> <path d=\"m17 3-3 6 1.5 3\" /> <path d=\"M2 12h6.5L10 9\" /> <path d=\"m20 10-1.5 2 1.5 2\" /> <path d=\"M22 12h-6.5L14 15\" /> <path d=\"m4 10 1.5 2L4 14\" /> <path d=\"m7 21 3-6-1.5-3\" /> <path d=\"m7 3 3 6h4\" />",
  "sparkles": "<path d=\"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z\" /> <path d=\"M20 3v4\" /> <path d=\"M22 5h-4\" /> <path d=\"M4 17v2\" /> <path d=\"M5 18H3\" />",
  "target": "<circle cx=\"12\" cy=\"12\" r=\"10\" /> <circle cx=\"12\" cy=\"12\" r=\"6\" /> <circle cx=\"12\" cy=\"12\" r=\"2\" />",
  "trending-up": "<path d=\"M16 7h6v6\" /> <path d=\"m22 7-8.5 8.5-5-5L2 17\" />",
  "user": "<path d=\"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2\" /> <circle cx=\"12\" cy=\"7\" r=\"4\" />",
  "zap": "<path d=\"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z\" />"
};

// 参考实例 hidden-state 的图示创作层（14 段画板）
// ctx 可用工具见 WORKFLOW.md Step 5；坐标基于 876 宽 × vh 高的图示区，动画时刻用 S/E/T(j) 相对语法

function buildBoards(ctx) {
  const { b, i, z, vh, S, E, T, tl, el, setXY, growIn, punch, mkSvg, drawPath, mkPath, arrow, dotAt } = ctx;
/* ---------- 自建动效辅助（引擎只提供结构原语；内容模式按本视频需要自行搭建） ---------- */
const SVG_NS = "http://www.w3.org/2000/svg";
function iconHtml(name, size, color, sw) {
  const s2 = size || 56, w = sw || 2, c = color || "#F2F0E4";
  return "<svg width=\"" + s2 + "\" height=\"" + s2 + "\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"" + c +
    "\" stroke-width=\"" + w + "\" stroke-linecap=\"round\" stroke-linejoin=\"round\" " +
    "style=\"display:block;filter:drop-shadow(0 0 5px " + c + "59);\">" + ((window.ICONS || {})[name] || "") + "</svg>";
}
function iconEl(z, name, x, y, size, color, t, anim) {
  const d = el("div", "", iconHtml(name, size, color), z);
  setXY(d, x, y, size);
  if (anim === "punch") punch(d, t); else growIn(d, t);
  return d;
}
function nodeIc(z, name, x, y, w, label, sub, color, t, icSize) {
  const c = color || "#F2F0E4", ic = icSize || 50;
  const d = el("div", "", "<div class='node' style='border-color:" + c + ";'>" +
    "<div style='display:flex;justify-content:center;'>" + iconHtml(name, ic, c) + "</div>" +
    "<div style='margin-top:8px;'>" + label + "</div>" +
    (sub ? "<small>" + sub + "</small>" : "") + "</div>", z);
  setXY(d, x, y, w); growIn(d, t); return d;
}
function stampAt(z, text, x, y, w, color, t, rot) {
  const d = el("div", "", "<span style='display:inline-block;border:5px double " + color +
    ";border-radius:12px;padding:8px 24px;transform:rotate(" + (rot === undefined ? -6 : rot) +
    "deg);font-size:46px;font-weight:800;color:" + color + ";letter-spacing:6px;text-shadow:0 0 9px " + color +
    "66;background:rgba(255,255,255,0.05);'>" + text + "</span>", z);
  setXY(d, x, y, w); d.style.textAlign = "center"; punch(d, t); return d;
}
function track(svg, d, color, width, t, dur, op) {
  const p = document.createElementNS(SVG_NS, "path");
  p.setAttribute("d", d); p.setAttribute("stroke", color);
  p.setAttribute("stroke-width", width); p.setAttribute("fill", "none");
  p.setAttribute("stroke-linecap", "round");
  p.style.opacity = (op === undefined) ? 0.5 : op;
  svg.appendChild(p); drawPath(p, t, dur); return p;
}
function travel(svg, d, color, t, opts) {
  const o = opts || {};
  if (o.track !== false) track(svg, d, color, o.width || 4, t, o.dur || 0.4, o.trackOp);
  const dot = dotAt(svg, 0, 0, o.r || 9, color);
  const dd = o.dur || 0.4, tv = o.travel || 1.0;
  tl.set(dot, { opacity: o.dotOp || 0.95 }, t + dd);
  tl.to(dot, { motionPath: { path: d, align: svg, alignOrigin: [0.5, 0.5] },
               duration: tv, repeat: o.repeat || 0, ease: "none" }, t + dd);
  if (o.fade !== undefined) tl.to(dot, { opacity: 0, duration: 0.4 }, o.fade);
  return dot;
}
function twinkle(e, t, dur, rep) {
  tl.to(e, { opacity: 0.15, duration: dur || 0.5, yoyo: true,
             repeat: (rep === undefined) ? 5 : rep, ease: "sine.inOut" }, t);
}
function countUp(span, target, t, dur, o) {
  const ob = { v: 0 };
  tl.to(ob, { v: target, duration: dur || 0.9, ease: "power1.out",
    onUpdate: () => { span.textContent = ((o && o.prefix) || "") + ((o && o.dec) ? ob.v.toFixed(1) : Math.round(ob.v)) + ((o && o.suffix) || ""); } }, t);
}

  const sc = b.sc;

  switch (sc.id) {

    /* 1. 两模型自然语言聊天 → 低效：打字气泡 + 慢速来回传话 + 印章 */
    case 1: {
      const svg = mkSvg(z, 876, vh);
      nodeIc(z, "bot", 25, 120, 200, "模型 A", "", "#86C5FA", S + 0.4);
      nodeIc(z, "bot", 651, 120, 200, "模型 B", "", "#86C5FA", S + 0.9);
      const bub = el("div", "", "<div style='border:3px solid #9FAF9F;border-radius:18px;background:rgba(242,240,228,0.06);padding:12px 20px;text-align:center;'>" +
        "<span class='td' style='display:inline-block;width:14px;height:14px;border-radius:50%;background:rgba(242,240,228,0.75);margin:0 7px;'></span>".repeat(3) + "</div>", z);
      setXY(bub, 265, 38, 190);
      growIn(bub, S + 1.3);
      bub.querySelectorAll(".td").forEach((d, k) => twinkle(d, S + 1.7 + k * 0.18, 0.4, 5));
      const lab = el("div", "", "<span style='font-size:27px;font-weight:600;color:rgba(242,240,228,0.66);'>自然语言 · 一大段话</span>", z);
      setXY(lab, 308, 102, 260); lab.style.textAlign = "center";
      growIn(lab, S + 1.6, 0.4, 0);
      travel(svg, "M 232 178 C 340 128 536 128 644 178", "#F2F0E4", S + 1.8, { r: 8, travel: 1.5, dur: 0.5, repeat: 0, fade: E - 0.1 });
      travel(svg, "M 644 215 C 536 262 340 262 232 215", "#9FAF9F", S + 2.6, { r: 8, travel: 1.5, dur: 0.4, repeat: 0, trackOp: 0.4, fade: E - 0.1 });
      stampAt(z, "低效", 348, 285, 180, "#FF8C7E", S + 3.3, -6);
      break;
    }

    /* 2. 不传文字传 hidden state：旧方式划掉 + 光点沿线流动 */
    case 2: {
      const svg = mkSvg(z, 876, vh);
      iconEl(z, "file-text", 208, 12, 40, "rgba(242,240,228,0.55)", S + 0.8);
      const old = el("div", "", "<div style='font-size:32px;font-weight:700;color:#9FAF9F;text-decoration:line-through;text-align:center;'>写字 → 读字</div>", z);
      setXY(old, 258, 14, 400);
      growIn(old, S + 0.8, 0.4, 0);
      nodeIc(z, "brain", 35, 172, 215, "大模型", "", "#86C5FA", S + 2.4);
      nodeIc(z, "cpu", 626, 172, 215, "小模型", "", "#E8D44D", S + 3.0);
      travel(svg, "M 262 238 L 614 238", "#86C5FA", S + 3.4, { width: 6, r: 11, travel: 0.9, dur: 0.5, repeat: 1, trackOp: 0.75, fade: E - 0.15 });
      const tag = el("div", "", "<span style='font-size:34px;font-weight:800;color:#86C5FA;text-shadow:0 0 8px rgba(134,197,250,0.35);'>hidden state</span>", z);
      setXY(tag, 298, 278, 280); tag.style.textAlign = "center";
      growIn(tag, S + 3.9, 0.4, 0);
      break;
    }

    /* 3. 压成几百个 token：Agent 系标签 + 漏斗吸入 + 压缩胶囊 */
    case 3: {
      const svg = mkSvg(z, 876, vh);
      [["Agent", 130, 170], ["Subagent", 320, 230], ["Model Council", 570, 250]].forEach((a, k) => {
        const c = el("div", "", "<div style='border:2px dashed rgba(242,240,228,0.4);border-radius:10px;padding:8px 14px;text-align:center;font-size:24px;font-weight:600;color:rgba(242,240,228,0.66);'>" + a[0] + "</div>", z);
        setXY(c, a[1], 4, a[2]); growIn(c, T(0) + 0.3 + k * 0.35, 0.35, 0);
      });
      nodeIc(z, "brain", 5, 172, 225, "模型 A", "", "#86C5FA", T(1) + 0.3);
      iconEl(z, "funnel", 373, 165, 110, "#E8D44D", T(1) + 1.2);
      for (let k = 0; k < 3; k++)
        travel(svg, "M 240 232 C 292 230 322 227 366 226", "#86C5FA", T(1) + 1.9 + k * 0.4, { r: 6, travel: 0.5, dur: 0.3, repeat: 1, trackOp: 0.35, fade: T(1) + 4.2 });
      nodeIc(z, "bot", 646, 172, 225, "模型 B", "", "#86C5FA", T(1) + 3.5);
      const tk = el("div", "", "<div style='border:3px dashed #86C5FA;border-radius:14px;background:rgba(134,197,250,0.10);padding:14px;text-align:center;'><div style='font-size:30px;font-weight:800;color:#86C5FA;'>几百个 token</div></div>", z);
      setXY(tk, 300, 325, 280); growIn(tk, T(1) + 2.5);
      travel(svg, "M 486 230 C 545 234 595 238 638 242", "#F2F0E4", T(1) + 4.5, { r: 7, travel: 0.6, dur: 0.3, repeat: 0, trackOp: 0.5 });
      const cap = el("div", "cap", "压缩后的结论", z);
      setXY(cap, 300, 428, 280); cap.style.textAlign = "center";
      growIn(cap, T(1) + 5.2, 0.4, 0);
      break;
    }

    /* 4. 丢掉的信息多得离谱：碎点漏进漏斗又洒落 + 印章 */
    case 4: {
      const svg = mkSvg(z, 876, vh);
      iconEl(z, "funnel", 383, 42, 110, "#F2F0E4", S + 0.3, "punch");
      for (let k = 0; k < 4; k++) {
        const d = dotAt(svg, 397 + k * 22, -10, 7, "#F2F0E4");
        tl.fromTo(d, { attr: { cy: -10 }, opacity: 0.9 },
          { attr: { cy: 118 }, duration: 0.45, repeat: 1, repeatDelay: 0.3, ease: "power1.in" }, S + 0.5 + k * 0.14);
      }
      for (let k = 0; k < 4; k++) {
        const d = dotAt(svg, 428, 195, 7, "#FF8C7E");
        tl.fromTo(d, { attr: { cx: 428, cy: 195 }, opacity: 0 },
          { attr: { cx: 452 + k * 22, cy: 330 + k * 6 }, opacity: 0.85, duration: 0.32, ease: "power1.in" }, S + 1.15 + k * 0.12);
        tl.to(d, { attr: { cy: 395 + k * 5 }, opacity: 0, duration: 0.45, ease: "power1.in" }, S + 1.5 + k * 0.12);
      }
      stampAt(z, "丢掉了", 148, 272, 270, "#FF8C7E", S + 1.4, -7);
      const sub = el("div", "cap", "多得离谱", z);
      setXY(sub, 330, 364, 240); sub.style.textAlign = "center";
      growIn(sub, S + 2.0, 0.4, 0);
      break;
    }

    /* 5. 2MB vs 17 bits：状态矩阵闪烁 → 压缩 → 手绘放大镜盯住一个小点 */
    case 5: {
      const svg = mkSvg(z, 876, vh);
      const big = el("div", "dotfield", "", z);
      setXY(big, 20, 40, 450); big.style.height = "300px";
      big.style.border = "4px solid #86C5FA"; big.style.borderRadius = "16px";
      growIn(big, T(0) + 0.5, 0.6, 0);
      iconEl(z, "database", 40, 58, 44, "#86C5FA", T(0) + 0.9);
      [[95, 140], [165, 205], [235, 120], [305, 235], [375, 160], [140, 285], [300, 90], [395, 265]].forEach((p, k) => {
        const d = dotAt(svg, p[0], p[1], 5, "#F2F0E4");
        tl.set(d, { opacity: 0.8 }, T(0) + 1.1 + k * 0.12);
        twinkle(d, T(0) + 1.5 + k * 0.12, 0.5, 14);
      });
      travel(svg, "M 488 190 L 648 190", "#86C5FA", T(0) + 3.4, { r: 8, travel: 0.8, dur: 0.4, repeat: 4, trackOp: 0.5, fade: T(0) + 8.8 });
      const dot = dotAt(svg, 752, 190, 10, "#FF8C7E");
      punch(dot, T(0) + 4.2);
      const mag = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      mag.setAttribute("cx", 752); mag.setAttribute("cy", 190); mag.setAttribute("r", 34);
      mag.setAttribute("stroke", "#E8D44D"); mag.setAttribute("stroke-width", 4);
      mag.setAttribute("fill", "none"); mag.setAttribute("stroke-dasharray", "11 9");
      mag.style.opacity = "0";
      svg.appendChild(mag);
      tl.fromTo(mag, { opacity: 0, scale: 1.6, transformOrigin: "752px 190px" },
        { opacity: 0.9, scale: 1, duration: 0.5, ease: "back.out(1.6)" }, T(0) + 4.8);
      mkPath(svg, "M 778 216 L 806 244", "#E8D44D", 5, T(0) + 5.2, 0.3);
      const bl = el("div", "", "<div style='font-size:32px;font-weight:800;color:#86C5FA;'>2MB 内部状态</div><div style='font-size:24px;color:rgba(242,240,228,0.62);margin-top:6px;'>上百万个数字</div>", z);
      setXY(bl, 60, 352, 400);
      growIn(bl, T(0) + 1.4, 0.4, 0);
      const dl = el("div", "", "<div style='font-size:32px;font-weight:800;color:#FF8C7E;'>17 bits</div><div style='font-size:24px;color:rgba(242,240,228,0.62);margin-top:6px;'>一个 token</div>", z);
      setXY(dl, 640, 352, 240);
      growIn(dl, T(0) + 4.6, 0.4, 0);
      for (let k = 0; k < 4; k++) {
        const d = dotAt(svg, 445, 150, 6, "#FF8C7E");
        tl.fromTo(d, { attr: { cx: 445, cy: 150 }, opacity: 0 },
          { attr: { cx: 530 + k * 18, cy: 245 + k * 14 }, opacity: 0.85, duration: 0.4, ease: "power1.in" }, T(1) + 0.2 + k * 0.14);
        tl.to(d, { opacity: 0, duration: 0.4 }, T(1) + 0.7 + k * 0.14);
      }
      stampAt(z, "被扔掉", 320, 425, 230, "#FF8C7E", T(1) + 0.9, -7);
      break;
    }

    /* 6. bridge 翻译器：手绘拱桥 + 光点过桥 */
    case 6: {
      const svg = mkSvg(z, 876, vh);
      nodeIc(z, "bot", 25, 92, 195, "模型 A", "", "#86C5FA", S + 0.5);
      nodeIc(z, "cpu", 656, 92, 195, "模型 B", "", "#86C5FA", S + 1.1);
      mkPath(svg, "M 235 210 L 641 210", "#E8D44D", 5, S + 1.5, 0.45);
      mkPath(svg, "M 252 210 C 340 130 536 130 624 210", "#E8D44D", 5, S + 1.9, 0.55);
      mkPath(svg, "M 322 210 L 322 182", "#E8D44D", 4, S + 2.35, 0.2);
      mkPath(svg, "M 554 210 L 554 182", "#E8D44D", 4, S + 2.45, 0.2);
      const lab = el("div", "", "<span style='font-size:38px;font-weight:800;color:#E8D44D;text-shadow:0 0 8px rgba(232,212,77,0.35);'>bridge</span>", z);
      setXY(lab, 348, 100, 180); lab.style.textAlign = "center";
      punch(lab, S + 2.1);
      travel(svg, "M 252 210 C 340 130 536 130 624 210", "#E8D44D", S + 2.7, { r: 8, travel: 0.85, dur: 0.3, repeat: 1, track: false, fade: E - 0.15 });
      const small = el("div", "cap", "很小，只是个翻译器", z);
      setXY(small, 288, 318, 300); small.style.textAlign = "center";
      growIn(small, S + 3.4, 0.4, 0);
      break;
    }

    /* 7. GLM-5.2 → Qwen-3.5：两块芯片 + 光点传递 */
    case 7: {
      const svg = mkSvg(z, 876, vh);
      nodeIc(z, "cpu", 20, 58, 330, "GLM-5.2", "", "#F2F0E4", S + 0.5);
      nodeIc(z, "cpu", 526, 58, 330, "Qwen-3.5", "", "#86C5FA", S + 1.3);
      travel(svg, "M 360 124 L 516 124", "#F2F0E4", S + 1.9, { r: 9, travel: 0.7, dur: 0.4, repeat: 1, trackOp: 0.7, fade: E - 0.1 });
      const cap = el("div", "cap", "跨厂商实验", z);
      setXY(cap, 348, 218, 180); cap.style.textAlign = "center";
      growIn(cap, S + 2.8, 0.4, 0);
      break;
    }

    /* 8. 大模型读题 → bridge → 小模型写答案；冻结 = 雪花 */
    case 8: {
      const svg = mkSvg(z, 876, vh);
      nodeIc(z, "brain", 5, 58, 255, "大模型", "只读题 · 不生成", "#86C5FA", T(0) + 0.6);
      nodeIc(z, "pencil", 616, 58, 255, "小模型", "写出答案", "#E8D44D", T(0) + 4.2);
      arrow(svg, "M 265 158 L 316 158", "#86C5FA", T(0) + 1.8, 0.4);
      mkPath(svg, "M 322 158 C 372 92 528 92 578 158", "#E8D44D", 5, T(0) + 2.2, 0.55);
      arrow(svg, "M 584 158 L 612 158", "#86C5FA", T(0) + 3.6, 0.35);
      const lab = el("div", "", "<span style='font-size:30px;font-weight:800;color:#E8D44D;'>bridge</span>", z);
      setXY(lab, 365, 60, 150); lab.style.textAlign = "center";
      punch(lab, T(0) + 2.6);
      travel(svg, "M 322 158 C 372 92 528 92 578 158", "#86C5FA", T(0) + 4.6, { r: 8, travel: 0.8, dur: 0.3, repeat: 2, track: false, fade: T(1) - 0.2 });
      const hs = el("div", "cap", "hidden state", z);
      setXY(hs, 348, 212, 180); hs.style.textAlign = "center"; hs.style.color = "#86C5FA";
      growIn(hs, T(0) + 5.2, 0.4, 0);
      const fz = el("div", "", "<div style='border:3px solid #86C5FA;border-radius:14px;background:rgba(134,197,250,0.08);padding:14px 22px;text-align:center;'><span style='font-size:28px;font-weight:800;color:rgba(242,240,228,0.85);'>两个模型完全冻结 · 不需微调</span></div>", z);
      setXY(fz, 170, 325, 540);
      punch(fz, T(1) + 0.5);
      iconEl(z, "snowflake", 102, 322, 50, "#86C5FA", T(1) + 0.9, "punch");
      iconEl(z, "snowflake", 728, 322, 50, "#86C5FA", T(1) + 1.1, "punch");
      break;
    }

    /* 9. 性能数据：图标统计卡 + 数字 count-up */
    case 9: {
      const cards = [
        { icon: "target", num: 50, suf: "%", label: "追回性能差距", c: "#E8D44D", x: 10, y: 18, t: T(0) + 0.8 },
        { icon: "trending-up", num: 25, suf: "%", label: "准确率提升", c: "#E8D44D", x: 310, y: 18, t: T(0) + 2.4 },
        { icon: "zap", num: null, txt: "2×", label: "难集最高提升", c: "#FF8C7E", x: 610, y: 18, t: T(0) + 4.0 },
        { icon: "gauge", num: 10, pre: "+", suf: "pt", label: "同等算力多拿", c: "#86C5FA", x: 150, y: 222, t: T(1) + 0.5 },
        { icon: "layers", num: 2.5, dec: true, suf: "×", label: "别家所需算力", c: "#FF8C7E", x: 470, y: 222, t: T(2) + 0.4 },
      ];
      cards.forEach(c => {
        const numHtml = (c.num === null) ? c.txt : "<span class='num'>0</span>";
        const d = el("div", "", "<div style='border:3px solid " + c.c + "55;border-radius:16px;background:" + c.c + "12;padding:16px 8px 14px;text-align:center;'>" +
          "<div style='display:flex;align-items:center;justify-content:center;gap:12px;'>" + iconHtml(c.icon, 38, c.c) +
          "<span style='font-size:58px;font-weight:800;color:" + c.c + ";line-height:1;'>" + numHtml + "</span></div>" +
          "<div style='font-size:23px;color:rgba(242,240,228,0.66);margin-top:10px;font-weight:600;'>" + c.label + "</div></div>", z);
        setXY(d, c.x, c.y, 256);
        growIn(d, c.t, 0.45, 20);
        if (c.num !== null) countUp(d.querySelector(".num"), c.num, c.t + 0.15, 0.9, { prefix: c.pre || "", suffix: c.suf || "", dec: c.dec });
      });
      break;
    }

    /* 10. API 只能吐 token：状态矩阵 → API 管道 → 单个 token */
    case 10: {
      const svg = mkSvg(z, 876, vh);
      const cap0 = el("div", "cap", "Multi-Agent 的默认通信协议：语言", z);
      setXY(cap0, 188, 2, 500); cap0.style.textAlign = "center";
      growIn(cap0, T(0) + 0.5, 0.4, 0);
      const inner = el("div", "dotfield", "", z);
      setXY(inner, 40, 58, 320); inner.style.height = "235px";
      inner.style.border = "4px solid #86C5FA"; inner.style.borderRadius = "16px";
      growIn(inner, T(0) + 1.1, 0.5, 0);
      iconEl(z, "database", 60, 76, 42, "#86C5FA", T(0) + 1.4);
      [[105, 135], [165, 180], [225, 120], [285, 215], [130, 240], [295, 150]].forEach((p, k) => {
        const d = dotAt(svg, p[0], p[1], 5, "#F2F0E4");
        tl.set(d, { opacity: 0.8 }, T(0) + 1.6 + k * 0.12);
        twinkle(d, T(0) + 2.0 + k * 0.12, 0.5, 10);
      });
      const il = el("div", "cap", "模型内部状态", z);
      setXY(il, 90, 302, 220); il.style.textAlign = "center";
      growIn(il, T(0) + 1.8, 0.4, 0);
      mkPath(svg, "M 378 150 L 588 150", "#9FAF9F", 4, T(0) + 2.4, 0.4);
      mkPath(svg, "M 378 210 L 588 210", "#9FAF9F", 4, T(0) + 2.5, 0.4);
      const api = el("div", "", "<span style='font-size:26px;font-weight:800;color:#9FAF9F;border:3px solid #9FAF9F;border-radius:8px;padding:4px 10px;background:rgba(34,51,43,0.92);'>API</span>", z);
      setXY(api, 448, 156, 80); api.style.textAlign = "center";
      punch(api, T(0) + 2.8);
      for (let k = 0; k < 3; k++)
        travel(svg, "M 380 180 L 586 180", "#86C5FA", T(0) + 3.2 + k * 0.5, { r: 6, travel: 0.7, dur: 0.3, repeat: 2, track: false, fade: T(1) - 0.1 });
      arrow(svg, "M 588 180 L 600 180", "#FF8C7E", T(1) + 0.1, 0.25);
      const tk = el("div", "", "<div style='border:3px solid #FF8C7E;border-radius:12px;background:rgba(255,140,126,0.12);padding:12px 18px;text-align:center;'><span style='font-size:30px;font-weight:800;color:#FF8C7E;'>token</span></div>", z);
      setXY(tk, 606, 148, 210);
      punch(tk, T(1) + 0.4);
      break;
    }

    /* 11. 人只能靠语言：脑间直连被画叉 */
    case 11: {
      const svg = mkSvg(z, 876, vh);
      nodeIc(z, "user", 35, 138, 190, "人 A", "", "#F2F0E4", S + 0.5);
      nodeIc(z, "user", 651, 138, 190, "人 B", "", "#F2F0E4", S + 1.1);
      iconEl(z, "brain", 104, 52, 44, "#FF8C7E", S + 1.3);
      iconEl(z, "brain", 728, 52, 44, "#FF8C7E", S + 1.45);
      track(svg, "M 154 78 C 320 38 556 38 722 78", "#FF8C7E", 4, S + 1.6, 0.5, 0.55);
      mkPath(svg, "M 402 40 L 458 96", "#FF8C7E", 7, S + 2.1, 0.18);
      mkPath(svg, "M 458 40 L 402 96", "#FF8C7E", 7, S + 2.25, 0.18);
      const bub = el("div", "", "<div style='border:3px solid #F2F0E4;border-radius:18px;background:rgba(242,240,228,0.06);padding:14px 22px;text-align:center;'><span style='font-size:32px;font-weight:700;'>只能靠语言</span></div>", z);
      setXY(bub, 288, 172, 300);
      growIn(bub, S + 1.8);
      const sub = el("div", "cap", "没法把神经状态直接复制给别人", z);
      setXY(sub, 138, 312, 600); sub.style.textAlign = "center";
      growIn(sub, S + 2.6, 0.4, 0);
      break;
    }

    /* 12. 模型没有这个限制：直接复制 + 复制图标 + 印章 */
    case 12: {
      const svg = mkSvg(z, 876, vh);
      nodeIc(z, "cpu", 30, 42, 220, "模型 A", "", "#E8D44D", S + 0.3);
      nodeIc(z, "cpu", 626, 42, 220, "模型 B", "", "#E8D44D", S + 0.7);
      travel(svg, "M 262 108 L 614 108", "#E8D44D", S + 1.0, { width: 7, r: 10, travel: 0.45, dur: 0.25, repeat: 0, trackOp: 0.8 });
      iconEl(z, "copy", 404, 180, 56, "#E8D44D", S + 1.2, "punch");
      stampAt(z, "直接复制", 280, 246, 316, "#E8D44D", S + 1.5, -5);
      break;
    }

    /* 13. 翻译层 hub：latent space 中枢 + 各专精模型星型接入 */
    case 13: {
      const svg = mkSvg(z, 876, vh);
      const hub = el("div", "", "<div class='node' style='border-color:#E8D44D;background:rgba(232,212,77,0.10);'>" +
        "<div style='display:flex;justify-content:center;'>" + iconHtml("layers", 46, "#E8D44D") + "</div>" +
        "<div style='margin-top:6px;color:#E8D44D;'>翻译层</div><small>latent space</small></div>", z);
      setXY(hub, 318, 212, 240);
      growIn(hub, T(0) + 1.0);
      nodeIc(z, "brain", 10, 8, 230, "大模型", "读 · 想", "#86C5FA", T(0) + 1.5);
      nodeIc(z, "pencil", 636, 8, 230, "小模型", "生成", "#86C5FA", T(0) + 1.9);
      nodeIc(z, "code", 10, 386, 210, "代码模型", "", "#F2F0E4", T(1) + 0.3, 40);
      nodeIc(z, "sigma", 333, 394, 210, "数学模型", "", "#F2F0E4", T(1) + 0.8, 40);
      nodeIc(z, "eye", 656, 386, 210, "视觉模型", "", "#F2F0E4", T(1) + 1.3, 40);
      track(svg, "M 125 145 C 220 190 290 212 350 236", "#E8D44D", 4, T(0) + 2.3, 0.4, 0.55);
      track(svg, "M 751 145 C 656 190 586 212 526 236", "#E8D44D", 4, T(0) + 2.4, 0.4, 0.55);
      track(svg, "M 115 386 C 210 356 290 340 350 328", "#E8D44D", 4, T(1) + 1.6, 0.35, 0.55);
      track(svg, "M 438 391 L 438 360", "#E8D44D", 4, T(1) + 1.75, 0.3, 0.55);
      track(svg, "M 761 386 C 666 356 586 340 526 328", "#E8D44D", 4, T(1) + 1.9, 0.35, 0.55);
      [["M 125 145 C 220 190 290 212 350 236", T(0) + 3.0],
       ["M 751 145 C 656 190 586 212 526 236", T(0) + 3.3],
       ["M 115 386 C 210 356 290 340 350 328", T(1) + 2.2],
       ["M 438 391 L 438 360", T(1) + 2.5],
       ["M 761 386 C 666 356 586 340 526 328", T(1) + 2.8]].forEach((a, k) => {
        travel(svg, a[0], "#E8D44D", a[1], { r: 6, travel: 0.8, dur: 0.25, repeat: 1, track: false, fade: T(1) + 5.6 + k * 0.1 });
      });
      const cap = el("div", "cap", "传的不再是 prompt", z);
      setXY(cap, 238, 506, 400); cap.style.textAlign = "center";
      growIn(cap, T(1) + 3.0, 0.4, 0);
      break;
    }

    /* 14. 文字只在最后跟人说话时：模型链传 hidden vector，只有对人吐文字 */
    case 14: {
      const svg = mkSvg(z, 876, vh);
      nodeIc(z, "brain", 15, 32, 185, "大模型", "", "#86C5FA", S + 0.4);
      nodeIc(z, "cpu", 230, 32, 185, "小模型", "", "#86C5FA", S + 0.8);
      nodeIc(z, "sparkles", 445, 32, 185, "专精模型", "", "#E8D44D", S + 1.2);
      nodeIc(z, "user", 672, 32, 185, "人", "", "#F2F0E4", S + 2.4);
      travel(svg, "M 202 98 L 228 98", "#86C5FA", S + 1.6, { r: 5, travel: 0.4, dur: 0.2, repeat: 2, trackOp: 0.5, fade: S + 4.0 });
      travel(svg, "M 417 98 L 443 98", "#86C5FA", S + 1.9, { r: 5, travel: 0.4, dur: 0.2, repeat: 2, trackOp: 0.5, fade: S + 4.0 });
      arrow(svg, "M 634 98 L 666 98", "#F2F0E4", S + 3.0, 0.4);
      const hv = el("div", "cap", "模型之间：hidden vector", z);
      setXY(hv, 40, 192, 340); growIn(hv, S + 2.1, 0.4, 0);
      const bub = el("div", "", "<div style='border:3px solid #F2F0E4;border-radius:18px;background:rgba(242,240,228,0.06);padding:14px 20px;text-align:center;'><span style='font-size:30px;font-weight:700;'>看到的文字</span></div>", z);
      setXY(bub, 622, 172, 250);
      punch(bub, S + 3.6);
      const cap = el("div", "cap", "文字只在最后一次跟人说话时出现", z);
      setXY(cap, 128, 330, 620); cap.style.textAlign = "center";
      growIn(cap, S + 4.3, 0.4, 0);
      break;
    }
  }
}
