# 黑板长卷短视频 · 模板工程包

配套文档：《黑板长卷短视频 · 制作流程手册》（WORKFLOW.md，随本压缩包一同发布）。
流程、规范、参数说明以文档为准；本包只提供代码与资源，不含任何文档外引用。

## 内容

```
blackboard-template/
├── template/                  引擎层（冻结层，除 bug 修复外不要动）
│   ├── composition/           渲染工程模板壳（index.html + package.json + hyperframes.json）
│   ├── engine/core.js         引擎本体：画布/画板三态/打字机/镜头漫游/CTA + 结构原语
│   ├── assets/                图片音频资源 + ATTRIBUTION.txt（素材署名）
│   └── tools/                 new_video.py / tts.py / build_scenes.py / mix.py
├── example/                   参考实例 hidden-state 的项目源文件
│   ├── script.txt             旁白原文
│   ├── config.js              项目参数
│   └── boards.js              图示创作示例（顶部为自建动效辅助 + 图标素材，仅参考接口用法）
└── cover/                     封面壳（3:4 / 1080×1440，大字报克制版，见手册 §7）
    ├── cover.html             固定壳 + 槽位。默认是示例期文案，每期必须替换
    └── README.md              填槽说明与 Chrome / Playwright 截图命令
```

## 快速开始

```bash
cd template/tools
python3 new_video.py ../../my-video   # 创建一个独立的视频项目目录
```

依赖：Node（hyperframes 渲染）、python3 + edge-tts + Pillow/numpy、ffmpeg/ffprobe。封面另需 Chrome/Chromium（或 Playwright）以及 Noto Serif CJK / 宋体。
完整流程见配套文档 §3（成片确认闸门 + 发布前封面轻闸门）。封面不走成片引擎：复制 `cover/`，只改槽位后截图。
