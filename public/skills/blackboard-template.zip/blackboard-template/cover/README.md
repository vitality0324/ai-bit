# 封面壳（大字报克制版）

3:4 封面，**1080×1440**。固定壳，每期只改 `cover.html` 里标了 `SLOT` 的几处。规范以配套手册 §7 为准。

`cover.html` 里现在填的是已验收示例期（标题「执行和验收拆开：/goal的实现原理」）。**出片前必须换成当期文案**，不要把示例词原样发出去。

## 每期改什么

通常 2–4 处，不要改版式层级，不要改色板：

- 标题文字和断行；哪些词套 `.goal`（accent）
- 眉题、底栏、印章上的字（印章最多 3 枚：`.exec` accent 描边 / `.split` 粉笔底反白 / `.accept` warm 描边）
- 中部一句（`p.mid`）和圆章（`.seal`）：不贴题就整段删掉

标题用衬线，默认 108px，不要超过 112px。两行是 `nowrap`，字太长会冲出外框，改断行或略降字号，不要挤成第三行。

禁止用 AI 生图。封面只从这份 HTML 截出来。

## 渲染

先确认机器上有 **Noto Serif CJK SC**（或宋体）和 **Noto Sans SC**。在本目录执行：

```bash
CHROME="$(command -v google-chrome || command -v google-chrome-stable || command -v chromium || command -v chromium-browser)"
"$CHROME" --headless=new --disable-gpu --hide-scrollbars \
  --force-device-scale-factor=1 \
  --window-size=1080,1440 \
  --screenshot=cover-1080x1440.png \
  "file://$(pwd)/cover.html"
```

`--force-device-scale-factor=1` 要留着，否则高分屏会截成 2 倍尺寸。

等价做法（Playwright，viewport 1080×1440，`deviceScaleFactor: 1`）：

```js
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({
    viewport: { width: 1080, height: 1440 },
    deviceScaleFactor: 1,
  });
  await page.goto('file://' + path.resolve('cover.html'));
  await page.screenshot({ path: 'cover-1080x1440.png' });
  await browser.close();
})();
```

核对尺寸：

```bash
python3 -c "from PIL import Image; im=Image.open('cover-1080x1440.png'); assert im.size==(1080,1440), im.size"
```

## 给用户看之前

自己打开 PNG 读一遍：

- 标题完整、在框内，没有冲出外框，没有挤成难看的三行
- 印章和圆章不压中部文案，也不压标题
- 粉笔字和暗绿板面对比够
- 图形元素不超过 2–3 类
- 尺寸是 1080×1440

不过就改槽位，重跑上面的截图命令。
