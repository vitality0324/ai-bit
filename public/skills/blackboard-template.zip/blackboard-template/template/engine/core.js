/* =====================================================================
 * 黑板长卷短视频引擎 core.js（一镜到底 · 无限画布）
 * 无限画布（整面黑板墙）+ 分镜板（board）三态 + 打字机 + 镜头漫游 + CTA
 *
 * 依赖（index.html 按序加载）：gsap / MotionPathPlugin / SCENES(scenes_data.js)
 *                            / EP_CONFIG(config.js) / buildBoards(boards.js) —— 本文件最后加载
 *
 * 每个视频只需提供：
 *   config.js  → EP_CONFIG（片长/列位/图示高/拉远镜头/关键词）
 *   boards.js  → buildBoards(ctx)（每段图示的独立创作实现；引擎只提供结构原语，
 *                内容动效辅助按本视频需要自建，视觉素材按内容自行选定）
 * ===================================================================== */

/* ---------- 视频项目参数（config.js）---------- */
const EP = window.EP_CONFIG;
const tl = gsap.timeline({ paused: true });
window.__timelines = window.__timelines || {};
window.__timelines["main"] = tl;
gsap.registerPlugin(MotionPathPlugin);

/* 片长同步给 hyperframes（root）与配音 clip */
document.getElementById("root").dataset.duration = EP.duration;
document.getElementById("narration").dataset.duration = EP.narrDuration;

const svgNS = "http://www.w3.org/2000/svg";
const camPan = document.getElementById("camPan");
const camZoom = document.getElementById("camZoom");

/* ================= 引擎常量（视觉规范，冻结勿改） ================= */
const CHAR_SPEED = 15;                    // 打字机速度：每秒 15 字
const PAUSE_CLAUSE = 0.16, PAUSE_END = 0.32;   // 逗号/句号停顿
const ENTER = 0.8;                        // 开场：直接落在第 1 张卡片，只做一次极轻推近
const OUT_DUR = EP.outDur;                // 收尾拉远时长
const OUT_START = EP.outStart;            // 收尾拉远开始时刻
const CTA_IN = EP.ctaIn;                  // 关注引导层入场时刻
const ZOOM_OUT = EP.zoomOut;              // 全景比例

const BW = 880;                           // 卡片宽 = 安全区宽（左右各 100）
const PADV = 34;                          // 卡片上下内边距
const GAP = 46;                           // 文字与图示间距
const MAXH = 1280;                        // 卡片高上限（安全区高 1320 留 40 余量）
const COLX = [240, 1160];                 // 两列卡片左边缘（安全区 240..1120 / 1160..2040）
const WORLD_W = 2280, WORLD_H = 14000;    // 世界画布尺寸
const Y0 = 900;                           // 首卡 y

/* ================= 关键词着色（视频项目 config.js 提供） ================= */
const KEYWORDS = EP.keywords;
function tokenize(text) {
  const toks = []; let i = 0;
  while (i < text.length) {
    let hit = null;
    for (const [kw, c] of KEYWORDS) if (text.startsWith(kw, i)) { hit = { t: kw, c }; break; }
    if (hit) { toks.push(hit); i += hit.t.length; }
    else { toks.push({ t: text[i], c: "" }); i++; }
  }
  return toks;
}

/* ================= 基础工具 ================= */
function el(tag, cls, html, parent) {
  const e = document.createElement(tag);
  e.className = cls ? cls + " hidden-el" : "hidden-el";
  if (html !== undefined) e.innerHTML = html;
  parent.appendChild(e);
  return e;
}
function setXY(e, x, y, w) {
  e.style.position = "absolute"; e.style.left = x + "px"; e.style.top = y + "px";
  if (w !== undefined) e.style.width = w + "px";
  return e;
}
function growIn(e, t, dur, dy) {
  tl.fromTo(e, { autoAlpha: 0, y: dy === undefined ? 24 : dy, scale: 0.94 },
    { autoAlpha: 1, y: 0, scale: 1, duration: dur || 0.45, ease: "back.out(1.4)", visibility: "visible" }, t);
}
function punch(e, t) {
  tl.fromTo(e, { autoAlpha: 0, scale: 1.45 },
    { autoAlpha: 1, scale: 1, duration: 0.34, ease: "power3.out", visibility: "visible" }, t);
}
function drawPath(p, t, dur) {
  const len = p.getTotalLength();
  p.style.strokeDasharray = `${len}`; p.style.strokeDashoffset = `${len}`;
  tl.to(p, { strokeDashoffset: 0, duration: dur || 0.6, ease: "power2.inOut" }, t);
}
function mkSvg(z, w, h) {
  const s = document.createElementNS(svgNS, "svg");
  s.setAttribute("class", "draw");
  s.setAttribute("width", w || 880); s.setAttribute("height", h || 660);
  z.appendChild(s); return s;
}
function mkPath(svg, d, color, width, t, dur) {
  const p = document.createElementNS(svgNS, "path");
  p.setAttribute("d", d); p.setAttribute("stroke", color);
  p.setAttribute("stroke-width", width || 4); p.setAttribute("fill", "none");
  p.setAttribute("stroke-linecap", "round");
  svg.appendChild(p); drawPath(p, t, dur); return p;
}
function arrow(svg, d, color, t, dur) {
  const p = document.createElementNS(svgNS, "path");
  p.setAttribute("d", d); p.setAttribute("stroke", color);
  p.setAttribute("stroke-width", 5); p.setAttribute("fill", "none");
  p.setAttribute("stroke-linecap", "round");
  // 关键：marker 不受 stroke-dasharray 影响，若创建时就挂上，线条未画出时箭头会提前露出来
  p.setAttribute("marker-end", "none");
  svg.appendChild(p);
  const dd = dur || 0.6;
  drawPath(p, t, dd);
  tl.set(p, { attr: { "marker-end": "url(#ah)" } }, t + dd * 0.85);
  return p;
}
function dotAt(svg, x, y, r, color) {
  const c = document.createElementNS(svgNS, "circle");
  c.setAttribute("cx", x); c.setAttribute("cy", y); c.setAttribute("r", r);
  c.setAttribute("fill", color); c.setAttribute("opacity", "0");
  svg.appendChild(c); return c;
}
/* 粉笔白/纸白箭头 marker 定义（ah=板面上用，ahw=结尾引导层用） */
(function defs() {
  const s = document.createElementNS(svgNS, "svg");
  s.setAttribute("width", "0"); s.setAttribute("height", "0"); s.style.position = "absolute";
  const d = document.createElementNS(svgNS, "defs");
  [["ah", "#F2F0E4"], ["ahw", "#FFFDF8"]].forEach(([id, color]) => {
    const m = document.createElementNS(svgNS, "marker");
    m.setAttribute("id", id); m.setAttribute("viewBox", "0 0 10 10");
    m.setAttribute("refX", "9"); m.setAttribute("refY", "5");
    m.setAttribute("markerWidth", "7"); m.setAttribute("markerHeight", "7");
    m.setAttribute("orient", "auto-start-reverse");
    const pa = document.createElementNS(svgNS, "path");
    pa.setAttribute("d", "M1 1L9 5L1 9"); pa.setAttribute("fill", "none");
    pa.setAttribute("stroke", color); pa.setAttribute("stroke-width", "2");
    pa.setAttribute("stroke-linecap", "round"); pa.setAttribute("stroke-linejoin", "round");
    m.appendChild(pa); d.appendChild(m);
  });
  s.appendChild(d); document.body.appendChild(s);
})();

/* ================= 阶段 1：建卡片 + 文字 ================= */
const cursor = document.createElement("span");
cursor.className = "cursor";
tl.to(cursor, { opacity: 0, duration: 0.42, repeat: Math.ceil(EP.duration / 0.84) + 20, yoyo: true, ease: "none" }, 0.15);

const B = SCENES.map((sc, i) => {
  const blk = el("div", "block", "", camPan);
  blk.style.width = BW + "px";
  const txt = document.createElement("div");
  txt.className = "txt"; txt.style.top = PADV + "px";
  blk.appendChild(txt);
  const vis = document.createElement("div");
  vis.className = "vis"; blk.appendChild(vis);
  const sentDivs = sc.sents.map(s => {
    const div = document.createElement("div");
    div.className = "sent";
    tokenize(s.text).forEach(tok => {
      const sp = document.createElement("span");
      sp.className = "ch" + (tok.c ? " " + tok.c : "");
      sp.textContent = tok.t; div.appendChild(sp);
    });
    txt.appendChild(div); return div;
  });
  return { sc, i, blk, txt, vis, sentDivs, x: 0, y: 0, h: 0, th: 0, cx: 0, cy: 0, s: 1 };
});

/* ================= 阶段 2：量高 → 排布 ================= */
B.forEach(b => { b.th = b.txt.offsetHeight; });
B.forEach((b, i) => {
  b.h = PADV + b.th + GAP + EP.vh[i] + PADV;
  b.s = Math.min(1, MAXH / b.h);
  if (i === 0) { b.y = Y0; }
  else {
    const prev = B[i - 1];
    const step = (EP.cols[i] === EP.cols[i - 1]) ? prev.h + 140 : prev.h * 0.70 + 300;
    b.y = prev.y + Math.max(560, step);
  }
  b.x = COLX[EP.cols[i]];
  b.cx = b.x + BW / 2;
  b.cy = b.y + b.h / 2;
  b.blk.style.left = b.x + "px";
  b.blk.style.top = b.y + "px";
  b.blk.style.height = b.h + "px";
  b.vis.style.top = (PADV + b.th + GAP) + "px";
  b.vis.style.height = EP.vh[i] + "px";
});
const WORLD_HH = Math.max(WORLD_H, B[B.length - 1].y + B[B.length - 1].h + 900);
camPan.style.width = WORLD_W + "px";
camPan.style.height = WORLD_HH + "px";

/* ================= 黑板墙质感：教室灯光暗角 ================= */
(function boardTexture() {
  const sm = document.createElement("div");
  sm.style.cssText = "position:absolute;left:0;top:0;width:100%;height:100%;z-index:0;pointer-events:none;" +
    "background:radial-gradient(ellipse 120% 88% at 50% 45%, transparent 58%, rgba(6,12,9,0.34) 100%);";
  camPan.appendChild(sm);
})();

/* ================= 阶段 3：画板之间的叙事虚线（在卡片下层） ================= */
const BOARD_LINES = {};   // i → 从板 i 底部到板 i+1 顶部的连线（归档缩小时同步补间端点）
(function boardLines() {
  const s = document.createElementNS(svgNS, "svg");
  s.setAttribute("class", "board");
  s.setAttribute("width", WORLD_W); s.setAttribute("height", WORLD_HH);
  camPan.appendChild(s);
  for (let i = 0; i < B.length - 1; i++) {
    const a = B[i], c = B[i + 1];
    const p = document.createElementNS(svgNS, "path");
    p.setAttribute("d", `M ${a.cx} ${a.cy + a.h / 2} L ${c.cx} ${c.cy - c.h / 2}`);
    p.setAttribute("stroke", "#B9C6B8"); p.setAttribute("stroke-width", "5");
    p.setAttribute("fill", "none"); p.setAttribute("stroke-dasharray", "16 14");
    p.setAttribute("stroke-linecap", "round");
    s.appendChild(p);
    tl.fromTo(p, { opacity: 0.22 }, { opacity: 0.75, duration: 0.7, ease: "power2.out" }, a.sc.end);
    BOARD_LINES[i] = p;
  }
})();

/* ================= 阶段 4：各段图示（boards.js 的 buildBoards，每个视频独立创作） ================= */
B.forEach(b => {
  const sc = b.sc, i = b.i;
  const S = sc.start, E = sc.end, sents = sc.sents;
  const ctx = {
    /* 当前画板上下文 */
    b, i, z: b.vis, vh: EP.vh[i],
    S, E, T: j => (sents[j] ? sents[j].t0 : S + 1),
    /* 结构原语（签名见本文件注释；内容动效辅助请在本视频 boards.js 里自建） */
    tl, el, setXY, growIn, punch, mkSvg, drawPath, mkPath, arrow, dotAt,
  };
  buildBoards(ctx);
});

/* 图示内容整体向中心缩进（scale 0.93 ≈ 四周 ~31px 内边距，避免贴木框） */
B.forEach(b => {
  const wrap = document.createElement("div");
  wrap.style.cssText = "position:absolute;left:0;top:0;width:100%;height:100%;transform:scale(0.93);transform-origin:50% 50%;";
  while (b.vis.firstChild) wrap.appendChild(b.vis.firstChild);
  b.vis.appendChild(wrap);
});

/* ================= 阶段 5：镜头 ================= */
const panX = c => 540 - c, panY = c => 960 - c;
// 开场：直接落在第 1 张卡片上，只做一次极轻的推近落定（不从全景推进）
tl.set(camPan, { x: panX(B[0].cx), y: panY(B[0].cy) }, 0);
tl.set(camZoom, { scale: B[0].s * 1.05 }, 0);
tl.to(camZoom, { scale: B[0].s, duration: ENTER, ease: "power2.out" }, 0);

for (let i = 0; i < B.length - 1; i++) {
  const a = B[i], c = B[i + 1];
  const dist = Math.hypot(c.cx - a.cx, c.cy - a.cy);
  let d = Math.min(1.3, Math.max(0.7, dist / 900));
  if (c.sc.end - c.sc.start < 3.5) d = Math.min(d, 0.9);
  const T = a.sc.end - d / 2;
  tl.to(camPan, { x: panX(c.cx), y: panY(c.cy), duration: d, ease: "power2.inOut" }, T);
  tl.to(camZoom, { scale: c.s, duration: d, ease: "power2.inOut" }, T);
}
// 关键节点：镜头拉远，露出整块画板（视频项目 config.js 的 zoomPeeks: [[段号, 开始, 结束], ...]）
EP.zoomPeeks.forEach(([id, ta, tb]) => {
  const b = B[id - 1];
  tl.to(camZoom, { scale: b.s * 0.88, duration: 1.0, ease: "power2.inOut" }, ta);
  tl.to(camZoom, { scale: b.s, duration: 1.0, ease: "power2.inOut" }, tb);
});
// 收尾：拉远看整块画板，随后盖上关注引导层
tl.to(camPan, { x: panX(WORLD_W / 2), y: panY(WORLD_HH / 2), duration: OUT_DUR, ease: "power2.inOut" }, OUT_START);
tl.to(camZoom, { scale: ZOOM_OUT, duration: OUT_DUR, ease: "power2.inOut" }, OUT_START);

/* ================= 阶段 6：卡片登场 / 归档（三态） ================= */
B.forEach((b, i) => {
  const S = b.sc.start, E = b.sc.end;
  // 待讲：板面暗淡的实木框小黑板
  tl.set(b.blk, { autoAlpha: 0.75, visibility: "visible" }, 0);
  // 正在讲：板面加深 + 粉笔辉光
  const actT = (i === 0) ? 0 : S;
  tl.fromTo(b.blk,
    { autoAlpha: 0.75, backgroundColor: "rgba(16,26,20,0.30)", boxShadow: "inset 0 0 70px rgba(8,14,10,0.35)" },
    { autoAlpha: 1, backgroundColor: "rgba(12,22,16,0.52)",
      boxShadow: "0 0 42px rgba(242,240,228,0.13), inset 0 0 70px rgba(8,14,10,0.50)",
      duration: 0.55, ease: "power2.out", visibility: "visible", immediateRender: false }, actT);
  // 已归档：缩小 + 褪色，留在黑板上
  const arcT = (i === B.length - 1) ? OUT_START : E - 0.1;
  tl.to(b.blk, { scale: 0.58, autoAlpha: 0.5, backgroundColor: "rgba(16,26,20,0.20)",
                 boxShadow: "inset 0 0 70px rgba(8,14,10,0.30)",
                 duration: 0.8, ease: "power2.inOut" }, arcT);
  // 归档缩小时，同步补间与这块板相连的连线端点（同 duration/ease，线头始终贴住缩小后的边缘）
  const SHRINK = 0.58, ARC_DUR = 0.8, ARC_EASE = "power2.inOut";
  if (BOARD_LINES[i] && i < B.length - 1) {
    const n = B[i + 1];
    tl.to(BOARD_LINES[i], { attr: { d: `M ${b.cx} ${b.cy + (b.h / 2) * SHRINK} L ${n.cx} ${n.cy - n.h / 2}` },
                            duration: ARC_DUR, ease: ARC_EASE }, arcT);
  }
  if (BOARD_LINES[i - 1] && i > 0) {
    const pr = B[i - 1];
    tl.to(BOARD_LINES[i - 1], { attr: { d: `M ${pr.cx} ${pr.cy + pr.h / 2} L ${b.cx} ${b.cy - (b.h / 2) * SHRINK}` },
                               duration: ARC_DUR, ease: ARC_EASE }, arcT);
  }
});

/* ================= 阶段 7：打字机（按配音 SRT 时间轴逐字） ================= */
B.forEach((b, i) => {
  b.sc.sents.forEach((s, j) => {
    const div = b.sentDivs[j];
    const chars = [...div.querySelectorAll(".ch")];
    const times = []; let t = 0;
    chars.forEach(c => {
      times.push(t); t += 1 / CHAR_SPEED;
      const ch = c.textContent;
      if ("，、；：".includes(ch)) t += PAUSE_CLAUSE;
      else if ("。？！".includes(ch)) t += PAUSE_END;
    });
    const start = (i === 0 && j === 0) ? Math.max(s.t0, ENTER * 0.6) : s.t0;
    const budget = Math.max(0.5, (s.t1 - start) * 0.9);
    const k = t > budget ? budget / t : 1;
    let typeEnd = start;
    chars.forEach((c, n) => {
      const tt = start + times[n] * k;
      tl.set(c, { visibility: "visible" }, tt);
      typeEnd = tt;
    });
    tl.call(() => { div.appendChild(cursor); cursor.style.visibility = "visible"; }, null, start);
    chars.forEach((c, n) => { tl.call(() => { c.after(cursor); }, null, start + times[n] * k); });
    tl.call(() => { cursor.style.visibility = "hidden"; }, null, typeEnd + 0.3);
    const kws = div.querySelectorAll(".r, .b, .g");
    if (kws.length) {
      tl.fromTo(kws, { scale: 1 },
        { scale: 1.07, duration: 0.15, yoyo: true, repeat: 1, ease: "power2.out", transformOrigin: "left bottom" },
        typeEnd + 0.08);
    }
  });
});

/* ================= 阶段 8：结尾关注引导层（盖在全景之上） ================= */
(function ctaLayer() {
  const wrap = document.getElementById("cta");
  const dim  = document.getElementById("ctaDim");
  const card = document.getElementById("ctaCard");
  const hint = document.getElementById("ctaHint");
  const arc  = document.getElementById("ctaArc");
  const m1   = card.querySelector(".follow");

  tl.set(wrap, { visibility: "hidden" }, 0);
  tl.set(wrap, { visibility: "visible" }, CTA_IN);

  // 暗化 + 画板文字让位：引导层出现时保留面板轮廓与图形线条作背景，文字全部退场
  const fadeEls = [];
  B.forEach(b => {
    fadeEls.push(b.txt);
    b.vis.querySelectorAll(".hidden-el").forEach(e => fadeEls.push(e));
  });
  tl.to(camZoom, { opacity: 0.55, duration: 0.5, ease: "power2.out" }, CTA_IN);
  tl.to(fadeEls, { autoAlpha: 0, duration: 0.45, ease: "power2.out" }, CTA_IN);
  tl.fromTo(dim, { opacity: 0 }, { opacity: 1, duration: 0.5, ease: "power2.out" }, CTA_IN);
  // 卡片弹入
  tl.fromTo(card, { autoAlpha: 0, y: 80, scale: 0.9 },
    { autoAlpha: 1, y: 0, scale: 1, duration: 0.7, ease: "back.out(1.5)" }, CTA_IN + 0.1);
  // 主文案呼吸脉冲，避免最后一屏是死画面
  tl.to(m1, { scale: 1.05, duration: 0.55, yoyo: true, repeat: 7,
              ease: "sine.inOut", transformOrigin: "50% 50%" }, CTA_IN + 0.85);

  // 指向右侧关注按钮的手绘弧线箭头
  // marker 不受 stroke-dasharray 控制：先挂 none，线画到 85% 再换成箭头，否则线条未出箭头先露
  const len = arc.getTotalLength();
  arc.style.strokeDasharray = `${len}`; arc.style.strokeDashoffset = `${len}`;
  const A0 = CTA_IN + 0.8, AD = 0.55;
  tl.to(arc, { strokeDashoffset: 0, duration: AD, ease: "power2.inOut" }, A0);
  tl.set(arc, { attr: { "marker-end": "url(#ahw)" } }, A0 + AD * 0.85);
  tl.fromTo(hint, { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.4, ease: "power2.out" }, A0);
})();
