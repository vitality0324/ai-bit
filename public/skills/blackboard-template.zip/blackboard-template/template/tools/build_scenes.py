#!/usr/bin/env python3
"""时间轴：python3 build_scenes.py <视频项目目录>
读 build/audio/s{i}.srt + 各段 wav 时长 → build/scenes_data.js
（绝对时间轴，逐句；段数自动识别 = 连续编号的 s{i}.wav 个数）
"""
import os, re, sys, json, shutil, subprocess

TEMPLATE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = os.path.dirname(TEMPLATE)
def _find_bin(name):
    p = shutil.which(name)
    if p:
        return p
    for c in ("/opt/homebrew/bin/" + name, "/usr/local/bin/" + name, "/usr/bin/" + name):
        if os.path.isfile(c):
            return c
    sys.exit("[错误] 未找到 %s，请安装 ffmpeg 并确保其在 PATH 中" % name)

FFPROBE = _find_bin("ffprobe")
TS = re.compile(r"(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})")


def to_sec(g):
    return int(g[0]) * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3]) / 1000.0


def wav_dur(f):
    r = subprocess.run([FFPROBE, "-v", "error", "-show_entries", "format=duration",
                        "-of", "default=noprint_wrappers=1:nokey=1", f],
                       capture_output=True, text=True)
    return float(r.stdout.strip())


def read_srt(path):
    out = []
    for b in re.split(r"\n\s*\n", open(path, encoding="utf-8").read().strip()):
        lines = [l for l in b.split("\n") if l.strip()]
        if len(lines) < 2:
            continue
        m = TS.search(lines[1])
        if not m:
            continue
        g = m.groups()
        text = "".join(lines[2:]).strip()
        if text:
            out.append({"t0": to_sec(g[:4]), "t1": to_sec(g[4:]), "text": text})
    return out


def main(ep):
    ep = os.path.abspath(ep)
    audio = os.path.join(ep, "build", "audio")
    segs, t, i = [], 0.0, 1
    while os.path.exists(f"{audio}/s{i}.wav"):
        d = wav_dur(f"{audio}/s{i}.wav")
        sents = read_srt(f"{audio}/s{i}.srt")
        for s in sents:
            s["t0"] = round(s["t0"] + t, 3)
            s["t1"] = min(round(s["t1"] + t, 3), round(t + d, 3))
        segs.append({"id": i, "start": round(t, 3), "end": round(t + d, 3), "sents": sents})
        t += d
        i += 1
    if not segs:
        sys.exit(f"[x] {audio} 下没有 s1.wav，先跑 tts.py")

    out = os.path.join(ep, "build", "composition", "scenes_data.js")
    with open(out, "w", encoding="utf-8") as f:
        f.write("const SCENES = ")
        f.write(json.dumps(segs, ensure_ascii=False, indent=2))
        f.write(";\n")
    print(f"共 {len(segs)} 段，总时长 {t:.1f}s，"
          f"{sum(len(s['sents']) for s in segs)} 句 → {out}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("用法: python3 build_scenes.py <视频项目目录>")
    main(sys.argv[1])
