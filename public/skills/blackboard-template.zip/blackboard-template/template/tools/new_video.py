#!/usr/bin/env python3
"""视频项目脚手架：python3 new_video.py <项目路径>

一个文档 → 一个短视频 → 一个独立项目目录。在 <项目路径> 处创建项目（相对/绝对路径均可），
并生成**自包含**的 build/composition 渲染工程：
  - index.html：模板壳 + 内联引擎（template/engine/core.js 注入 @@ENGINE@@ 标记处）
  - assets  → symlink 到 template/assets（黑板墙/木框/BGM）
  - brand   → symlink 到项目 brand/（账号 logo）
  - audio   → symlink 到 build/audio（tts.py 输出的配音）
  - config.js / boards.js → symlink 到项目源文件（编辑源文件即生效）
  - scenes_data.js 由 build_scenes.py 生成到工程内

已存在的文件不会被覆盖（可安全重跑刷新渲染工程）。
"""
import os, sys, shutil, json

TEMPLATE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # template/
DEFAULT_BRAND_NAME = "下海研究员"
DEFAULT_BRAND = {
    "name": DEFAULT_BRAND_NAME,
    "logo": "",  # 留空时使用模板内置 logo；也可填写相对项目目录的图片路径。
}


def write_if_absent(path, content):
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    return False


def scaffold(project):
    comp = os.path.join(project, "build", "composition")
    audio = os.path.join(project, "build", "audio")
    os.makedirs(comp, exist_ok=True)
    os.makedirs(audio, exist_ok=True)

    # 1) package.json / hyperframes.json
    for f in ("package.json", "hyperframes.json"):
        dst = os.path.join(comp, f)
        if not os.path.exists(dst):
            shutil.copy(os.path.join(TEMPLATE, "composition", f), dst)

    # 2) 品牌身份：项目级 brand.json + brand/logo.png，避免模板硬编码账号。
    brand_file = os.path.join(project, "brand.json")
    if not os.path.exists(brand_file):
        with open(brand_file, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_BRAND, f, ensure_ascii=False, indent=2)
            f.write("\n")
    try:
        brand = json.load(open(brand_file, encoding="utf-8"))
    except Exception as e:
        sys.exit(f"[x] 无法读取 {brand_file}: {e}")
    brand_name = str(brand.get("name", "")).strip()
    if not brand_name:
        sys.exit(f"[x] {brand_file} 的 name 不能为空")
    brand_dir = os.path.join(project, "brand")
    os.makedirs(brand_dir, exist_ok=True)
    brand_logo = os.path.join(brand_dir, "logo.png")
    custom_logo = str(brand.get("logo", "")).strip()
    if custom_logo:
        custom_logo = custom_logo if os.path.isabs(custom_logo) else os.path.join(project, custom_logo)
        custom_logo = os.path.abspath(custom_logo)
        if not os.path.isfile(custom_logo):
            sys.exit(f"[x] brand.json 指定的 logo 不存在: {custom_logo}")
        if custom_logo != os.path.abspath(brand_logo):
            shutil.copyfile(custom_logo, brand_logo)
    if not os.path.exists(brand_logo):
        shutil.copyfile(os.path.join(TEMPLATE, "assets", "logo.png"), brand_logo)

    # 3) index.html：模板壳 + 品牌槽位 + 内联引擎
    shell = open(os.path.join(TEMPLATE, "composition", "index.html"), encoding="utf-8").read()
    engine = open(os.path.join(TEMPLATE, "engine", "core.js"), encoding="utf-8").read()
    html = (shell.replace("@@ENGINE@@", "<script>\n" + engine + "\n    </script>")
                 .replace("@@BRAND_NAME@@", brand_name)
                 .replace("@@BRAND_LOGO@@", "brand/logo.png"))
    with open(os.path.join(comp, "index.html"), "w", encoding="utf-8") as f:
        f.write(html)

    # 4) symlinks（相对 symlink，项目目录可整体移动）
    def link(name, target_rel):
        dst = os.path.join(comp, name)
        if os.path.lexists(dst):
            return
        os.symlink(target_rel, dst)

    link("assets", os.path.relpath(os.path.join(TEMPLATE, "assets"), comp))
    link("brand", os.path.relpath(brand_dir, comp))
    link("audio", os.path.relpath(audio, comp))
    link("config.js", os.path.relpath(os.path.join(project, "config.js"), comp))
    link("boards.js", os.path.relpath(os.path.join(project, "boards.js"), comp))

    # 5) 项目源文件骨架（已存在则不覆盖）
    write_if_absent(os.path.join(project, "script.txt"),
                    "每段文案之间用一个空行分隔。\n段落顺序即画板顺序，段数不限。\n\n在这里粘贴第一段旁白文字。\n")
    write_if_absent(os.path.join(project, "config.js"), """// 视频项目参数（具体含义见 WORKFLOW.md Step 3）
window.EP_CONFIG = {
  duration: 0,          // 片长（秒）= 配音时长 + 结尾引导停留（mix 前先填配音时长+4.7）
  narrDuration: 0,      // 配音时长（秒，tts.py 报告里有）
  outStart: 0,          // 收尾拉远开始时刻 ≈ narrDuration - 2
  outDur: 1.6,          // 收尾拉远时长（固定 1.6）
  ctaIn: 0,             // 引导层入场 ≈ narrDuration - 0.3
  zoomOut: 0.137,       // 全景比例（固定）
  cols: [],             // 每段所在列（0=左 1=右），长度 = 段数
  vh: [],               // 每段图示区高度，长度 = 段数
  zoomPeeks: [],        // 关键节点拉远 [[段号(1起), 开始, 结束], ...]
  keywords: [],         // 打字机关键词着色 [["词","r|g|b"], ...]
};
""")
    write_if_absent(os.path.join(project, "boards.js"), """// 图示创作层：按文案为每一段画板独立设计实现（规范与可用 API 见 WORKFLOW.md §5）
function buildBoards(ctx) {
  const { b, i, z, vh, S, E, T, tl, el, setXY, growIn, punch, mkSvg, mkPath, arrow,
          dotAt, iconHtml, iconEl, nodeIc, stampAt, track, travel, twinkle, countUp } = ctx;
  // 示例：第 1 段画一个图标节点
  // const svg = mkSvg(z, 876, vh);
  // nodeIc(z, "bot", 340, 100, 200, "节点", "", "#86C5FA", S + 0.4);
}
""")

    print(f"""[ok] {project}/ 就绪
  script.txt / config.js / boards.js   ← 项目源文件（按 WORKFLOW.md 逐步填充）
  brand.json / brand/logo.png          ← 品牌身份（默认“下海研究员”）
  build/audio/                          ← tts.py 输出
  build/composition/                    ← 自包含渲染工程（engine 已内联，assets/audio 为 symlink）
注意：模板引擎 template/engine/core.js 若有修改，重跑本命令刷新 index.html（不会覆盖项目源文件）。""")


def main():
    if len(sys.argv) != 2:
        sys.exit("用法: python3 new_video.py <项目路径>   例: python3 new_video.py ../../my-video")
    project = os.path.abspath(sys.argv[1])
    os.makedirs(project, exist_ok=True)
    scaffold(project)


if __name__ == "__main__":
    main()
