#!/usr/bin/env python3
"""TTS 配音：python3 tts.py <视频项目目录>
读 <项目>/script.txt（空行分段）→ edge-tts 逐段生成 mp3+srt
→ 转 wav → concat → loudnorm(-14 LUFS) → build/audio/narration.m4a
并报告每段时长（用于回填 config.js 的 narrDuration 等）。

音色/语速为账号固定风格：zh-CN-YunjianNeural，语速 +30%。
"""
import os, re, sys, json, shutil, subprocess, time

TEMPLATE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = os.path.dirname(TEMPLATE)
def _find_bin(name):
    p = shutil.which(name)
    if p:
        return p
    for c in ("/opt/homebrew/bin/" + name, "/usr/local/bin/" + name, "/usr/bin/" + name):
        if os.path.isfile(c):
            return c
    sys.exit("[错误] 未找到 %s，请安装 ffmpeg 并确保其在 PATH 中" % name)

FFMPEG = _find_bin("ffmpeg")
FFPROBE = _find_bin("ffprobe")
VOICE = "zh-CN-YunjianNeural"
RATE = "+30%"
LOUDNESS = -14          # 旁白目标响度（mix.py 的固化配方以此为前提）
TRIES = 6


def find_edge_tts():
    p = shutil.which("edge-tts")
    if p:
        return p
    p = os.path.expanduser("~/.workbuddy/binaries/python/envs/default/bin/edge-tts")
    if os.path.exists(p):
        return p
    sys.exit("[x] 找不到 edge-tts，请先 pip install edge-tts")


def read_segments(ep):
    txt = open(os.path.join(ep, "script.txt"), encoding="utf-8").read().strip()
    segs = [s.strip() for s in re.split(r"\n\s*\n", txt) if s.strip()]
    if len(segs) < 2:
        sys.exit("[x] script.txt 至少需要 2 段（空行分隔）")
    return segs


def gen_one(edge, idx, text, out):
    mp3, srt = os.path.join(out, f"s{idx}.mp3"), os.path.join(out, f"s{idx}.srt")
    for a in range(TRIES):
        try:
            subprocess.run([edge, "--voice", VOICE, f"--rate={RATE}", "--text", text,
                            "--write-media", mp3, "--write-subtitles", srt],
                           check=True, capture_output=True, timeout=120)
            if os.path.exists(mp3) and os.path.getsize(mp3) > 0:
                return
            raise RuntimeError("empty audio")
        except Exception as e:
            print(f"[retry {a+1}/{TRIES}] s{idx}: {e}")
            if a == TRIES - 1:
                raise
            time.sleep(1.2 * (a + 1))


def dur_of(f):
    r = subprocess.run([FFPROBE, "-v", "error", "-show_entries", "format=duration",
                        "-of", "default=noprint_wrappers=1:nokey=1", f],
                       capture_output=True, text=True)
    return float(r.stdout.strip())


def main(ep):
    ep = os.path.abspath(ep)
    audio = os.path.join(ep, "build", "audio")
    os.makedirs(audio, exist_ok=True)
    edge = find_edge_tts()
    segs = read_segments(ep)
    n = len(segs)
    print(f"共 {n} 段，音色 {VOICE}（{RATE}）")

    # 1) 逐段生成
    for i, t in enumerate(segs, 1):
        gen_one(edge, i, t, audio)
        print(f"[ok] s{i}: {len(t)} 字")

    # 2) mp3 -> wav（48k 立体声）
    for i in range(1, n + 1):
        subprocess.run([FFMPEG, "-y", "-i", f"{audio}/s{i}.mp3", "-ar", "48000", "-ac", "2",
                        "-c:a", "pcm_s16le", f"{audio}/s{i}.wav"], check=True, capture_output=True)

    # 3) concat
    with open(f"{audio}/concat.txt", "w") as f:
        for i in range(1, n + 1):
            f.write(f"file 's{i}.wav'\n")
    subprocess.run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", f"{audio}/concat.txt",
                    "-c", "copy", f"{audio}/raw.wav"], check=True, capture_output=True)

    # 4) loudnorm 两遍（线性模式，目标 -14 LUFS）
    p1 = subprocess.run([FFMPEG, "-i", f"{audio}/raw.wav",
                         "-af", f"loudnorm=I={LOUDNESS}:TP=-1.5:LRA=11:linear=true:print_format=json",
                         "-f", "null", "-"], capture_output=True, text=True)
    err = p1.stderr
    data = json.loads(err[err.rfind("{"): err.rfind("}") + 1])
    af = (f"loudnorm=I={LOUDNESS}:TP=-1.5:LRA=11:linear=true"
          f":measured_I={data['input_i']}:measured_TP={data['input_tp']}"
          f":measured_LRA={data['input_lra']}:measured_thresh={data['input_thresh']}"
          f":offset={data['target_offset']}")
    subprocess.run([FFMPEG, "-y", "-i", f"{audio}/raw.wav", "-af", af, "-ar", "48000", "-ac", "2",
                    "-c:a", "aac", "-b:a", "320k", f"{audio}/narration.m4a"],
                   check=True, capture_output=True)

    # 5) 报告（回填 config.js 用）
    total = 0.0
    print("\n=== 各段时长（build_scenes.py 会自动读取，无需手抄） ===")
    for i in range(1, n + 1):
        d = dur_of(f"{audio}/s{i}.wav")
        total += d
        print(f"s{i}: {d:6.1f}s")
    final = dur_of(f"{audio}/narration.m4a")
    print(f"\n配音成片 narration.m4a: {final:.1f}s（分段合计 {total:.1f}s）")
    print("回填 config.js：narrDuration=%.1f, outStart=%.1f, ctaIn=%.1f, duration=%.1f"
          % (final, final - 2.0, final - 0.3, final + 4.7))
    print("ALL_DONE")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("用法: python3 tts.py <视频项目目录>")
    main(sys.argv[1])
