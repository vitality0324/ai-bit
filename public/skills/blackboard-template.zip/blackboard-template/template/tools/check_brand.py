#!/usr/bin/env python3
"""品牌门禁：python3 check_brand.py <视频项目目录>

在任何 render 前运行。检查项目级品牌配置、CTA DOM 与 logo 文件是否一致，
避免模板或资源继承错误导致结尾关注卡写错账号。
"""
import hashlib
import html
import json
import os
import re
import sys

TEMPLATE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_BRAND_NAME = "下海研究员"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main(project):
    project = os.path.abspath(project)
    brand_file = os.path.join(project, "brand.json")
    index_file = os.path.join(project, "build", "composition", "index.html")
    project_logo = os.path.join(project, "brand", "logo.png")
    errors = []

    if not os.path.isfile(brand_file):
        sys.exit(f"[x] 缺少品牌配置: {brand_file}")
    try:
        brand = json.load(open(brand_file, encoding="utf-8"))
    except Exception as e:
        sys.exit(f"[x] 无法读取品牌配置 {brand_file}: {e}")

    brand_name = str(brand.get("name", "")).strip()
    if not brand_name:
        errors.append("brand.json 的 name 为空")
    if brand_name != DEFAULT_BRAND_NAME:
        errors.append(f"品牌名不是 {DEFAULT_BRAND_NAME!r}: {brand_name!r}")

    if not os.path.isfile(index_file):
        errors.append(f"缺少渲染入口: {index_file}")
        html_text = ""
    else:
        html_text = open(index_file, encoding="utf-8").read()
        m = re.search(r'<div class="m1">(.*?)</div>', html_text)
        actual_name = html.unescape(m.group(1).strip()) if m else ""
        if actual_name != brand_name:
            errors.append(f"CTA 文案不一致: DOM={actual_name!r}, brand.json={brand_name!r}")
        m = re.search(r'<div class="av"><img src="([^"]+)"', html_text)
        actual_src = m.group(1) if m else ""
        if actual_src != "brand/logo.png":
            errors.append(f"CTA logo 路径不一致: {actual_src!r}")

    if not os.path.isfile(project_logo):
        errors.append(f"缺少项目 logo: {project_logo}")
    else:
        custom = str(brand.get("logo", "")).strip()
        expected = custom or os.path.join(TEMPLATE, "assets", "logo.png")
        expected = expected if os.path.isabs(expected) else os.path.join(project, expected)
        expected = os.path.abspath(expected)
        if not os.path.isfile(expected):
            errors.append(f"brand.json 指定的 logo 不存在: {expected}")
        elif sha256(project_logo) != sha256(expected):
            errors.append(f"logo 哈希不一致: {project_logo} != {expected}")

    if errors:
        print("[x] 品牌门禁失败")
        for e in errors:
            print("  - " + e)
        return 1

    print(f"[ok] 品牌门禁通过: {brand_name} · {project_logo}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("用法: python3 check_brand.py <视频项目目录>")
    sys.exit(main(sys.argv[1]))
