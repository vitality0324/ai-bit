#!/usr/bin/env python3
"""混音 + 成片合成：python3 mix.py <视频项目目录> [--mux <渲染出的无声视频>]

固化配方（2026-09-11 调整：旁白偏小、BGM 偏大）：
  - 旁白：tts.py 归一到 -14 LUFS 后再 +2 dB（≈ -12 LUFS），限幅器保护峰值
  - BGM：DJ L《C260》，volume=0.22（≈ -21.3 LUFS），无闪避、全程恒定
  - 淡入 1.5s / 淡出 5.5s
  - 音轨总长 = config.js 的 duration

不带 --mux 时只输出 build/audio/narration_bgm.m4a；
带 --mux 时把音轨与渲染视频合成最终成片 build/final.mp4（视频流不重编码）。
"""
import os, sys, json, re, shutil, subprocess

TEMPLATE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = os.path.dirname(TEMPLATE)
def _find_bin(name):
    p = shutil.which(name)
    if p:
        return p
    for c in ("/opt/homebrew/bin/" + name, "/usr/local/bin/" + name, "/usr/bin/" + name):
        if os.path.isfile(c):
            return c
    sys.exit("[错误] 未找到 %s，请安装 ffmpeg 并确保其在 PATH 中" % name)

FFMPEG = _find_bin("ffmpeg")
BGM = os.path.join(TEMPLATE, "assets", "bgm", "c260.mp3")
BGM_GAIN = 0.22
NAR_GAIN = 2.0  # 旁白增益 dB，tts 已归一 -14 LUFS，+2 后约 -12 LUFS
FADE_IN, FADE_OUT = 1.5, 5.5


def read_duration(ep):
    src = open(os.path.join(ep, "config.js"), encoding="utf-8").read()
    m = re.search(r"duration:\s*([\d.]+)", src)
    if not m or float(m.group(1)) <= 0:
        sys.exit("[x] config.js 的 duration 未回填")
    return float(m.group(1))


def main(ep, mux_video=None):
    ep = os.path.abspath(ep)
    audio = os.path.join(ep, "build", "audio")
    d = read_duration(ep)
    narration = f"{audio}/narration.m4a"
    if not os.path.exists(narration):
        sys.exit(f"[x] 缺 {narration}，先跑 tts.py")

    out_audio = f"{audio}/narration_bgm.m4a"
    fc = (f"[0:a]apad=whole_dur={d},volume={NAR_GAIN}dB,"
          f"alimiter=limit=0.891:level=false[nar];"
          f"[1:a]atrim=0:{d},asetpts=PTS-STARTPTS,volume={BGM_GAIN},"
          f"afade=t=in:st=0:d={FADE_IN},afade=t=out:st={d - FADE_OUT:.2f}:d={FADE_OUT}[bg];"
          f"[nar][bg]amix=inputs=2:duration=first:normalize=0,"
          f"alimiter=limit=0.891:level=false[aout]")
    subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-i", narration, "-i", BGM,
                    "-filter_complex", fc, "-map", "[aout]", "-c:a", "aac", "-b:a", "192k",
                    out_audio], check=True)
    print(f"[ok] 混音 → {out_audio}（片长 {d}s，narration +{NAR_GAIN}dB，BGM gain {BGM_GAIN}）")

    if mux_video:
        mux_video = os.path.abspath(mux_video)
        final = os.path.join(ep, "build", "final.mp4")
        subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-i", mux_video, "-i", out_audio,
                        "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "copy",
                        "-shortest", final], check=True)
        print(f"[ok] 成片 → {final}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("用法: python3 mix.py <视频项目目录> [--mux <渲染视频.mp4>]")
    main(sys.argv[1], sys.argv[3] if "--mux" in sys.argv else None)
